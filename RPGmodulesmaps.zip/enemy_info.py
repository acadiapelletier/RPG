print("""To help I've written down some key info for you on your journey. Here is the list of potential enemies you will come accross:""")

oaf_info = {'name': 'King Bulbin', 'traits': ['Craves power', 'Smelly',
'Anger issues'], 'fighting info': 'Hits hard, moves slow'}

elves_info = {'name': "They don't have names", 'traits': ['Loyal to the king', 'Live to serve the king', """
They do not talk"""], '\nfighting information': "Attacks do less damage but move quicker."}

for title, info in oaf_info.items():
  print(f"\n\t{title}: {info}")

for title, info in elves_info.items():
  print(f"\n\t{title}: {info}")