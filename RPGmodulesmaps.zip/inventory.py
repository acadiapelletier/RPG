from game import inventory

print(" ")
print(f"""What would you like to see?
Type 'quit' when finished. {inventory}""")
