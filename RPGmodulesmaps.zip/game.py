print(" ")
print("""Hello human... It appears you have been trapped in a dungeon.
If you look to your left you can see there is some sort of book
and map. Try picking it up by typing 'pick up'.""")

prompt = 'ACTION: '
inventory = []

while True:
  key = input(prompt)

  if key == 'pick up':
    print("""You have picked up a new item!
You can view it in in your inventory.""")
    inventory.append('Mysterious Book')
    break
  else:
    print("Huh? That is not an available action.")
print(" ")

print("""Choose one of the following actions:
*Open inventory""")

prompt = 'ACTION: '

while True:
  key = input(prompt)

  if key == 'open inventory':
    import inventory as inventory
    break
  else:
    print("Huh? That is not an available action.")

prompt = 'ACTION: '

while True:
  key = input(prompt)

  if key == 'mysterious book':
    import enemy_info as enemy_info
    import game_map as game_map
