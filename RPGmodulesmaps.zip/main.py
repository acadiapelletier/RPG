# Course: CS 30
# Period: morning
# Date created: 21 / 02 / 10
# Name: Acadia Pelletier
# Description: RPG Modules and Maps

print("""Welcome to Flee the Capture
Choose one of the following options: \n*Start Game \n*Quit""")

prompt = 'ACTION: '

while True:
  key = input(prompt)

  if key == 'start game':
    print("Starting game...")
    import game as game
  elif key == 'quit':
    print("Quitting game.")
    break
  else:
    break