from game import inventory

print(f"""What would you like to see?
Type 'quit' when finished:
{inventory}""")

class Inventory():

  def __init__(self, item, description):
    self.item = item.title()
    self.description = description
  
  def describe_item(self):
    message = f"{self.item}: {self.description}"
    print(message)

class Fight_Items(Inventory):
  def __init__(self, item, description):
    super().__init__(item, description)
    self.fight_abilities = Fight_Abilities()

class Fight_Abilities():
  def __init__(self, abilities=[]):
    self.abilities = abilities
  
  def show_abilities(self):
    print("""\nAbilities during fight:""")
    
    if self.abilities:
      for ability in self.abilities:
        print(f"- {ability}")
    else:
      print("This item cannot be used during a fight.")
