print("""To help I've written down
some key info for you on your journey.
Here is the list of potential enemies
you will come accross:""")


class Enemy():
  def __init__(self, name, traits, fighting_info):
    self.name = name.title()
    self.traits = traits
    self.fighting_info = fighting_info

  def describe_enemy(self):
    message = f"""Enemy name: {self.name}
    Traits: {self.traits}
    Fighting info: {self.fighting_info}"""
    print(message)

enemy_oaf = Enemy('King Bulbin', ["""
Craves power""", 'Smelly',
'Anger issues'], 'Hits hard, moves slow')

enemy_elf = Enemy("They don't have names", ["""
Loyal to the king""", "Live to serve the king",
"They do not talk"], """Attacks do
less damage but they move quicker.""")

enemy_elf.describe_enemy()
enemy_oaf.describe_enemy()
