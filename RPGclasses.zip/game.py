print(" ")
print("""Hello human... It appears
you have been trapped in a dungeon.
If you look to your left you can
see there is some sort of book
and map. Try picking it up by typing 'pick up'.""")

prompt = 'ACTION: '
inventory = []

while True:
  key = input(prompt)

  if key == 'pick up':
    print("""You have picked up a new item!
You can view it in in your inventory.""")
    inventory.append('Mysterious Book')
    break
  else:
    print("Huh? That is not an available action.")
print(" ")

print("""Choose one of the following actions:
*open inventory""")

prompt = 'ACTION: '


while True:
  key = input(prompt)

  if key == 'open inventory':
    from inventory import Inventory
    inventory = Inventory('Mysterious Book',
    """Book found in the dungeon you started in,
    origins are unknown""")
    inventory.describe_item()
    break
  elif key == 'quit':
    break
  else:
    print("Huh? That is not an available action.")

prompt = 'ACTION: '

while True:
  key = input(prompt)

  if key == 'mysterious book':
    import enemy as enemy
    import game_map as game_map
    break
  elif key == 'quit':
    break
