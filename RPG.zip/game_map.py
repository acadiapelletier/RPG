# Shows the game map in the mysterious book

def show_gamemap():
  game_map = [[' ', ' ', '\t\t\t\tFinal room', '---', 'Room'],
['\t\t\t\t\t\t\t\t\t |'], [' ', ' ', '\t\t\t\t\t\tRoom', '---', 'Room'],
['\t\t\t\t\t\t\t |', '\t\t\t|'],
['Dungeon room', '---', 'First Room', '-', 'Room', '---', 'Room']]

  print(' ')
  print("""When trying to escape, there will be
two decisions once you come to a cross,
I've made a small map to help better understand: """)

  for r in game_map:
    for d in r:
      print(d, end=' ')
    print()
